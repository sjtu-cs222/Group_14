package ats;

import java.util.ArrayList;

public class Main {
	
	public static ArrayList<Person> createListOfPersons(int amount) {
		ArrayList<Person> list = new ArrayList<Person>();
		for (int i = 0; i < amount; i++) {
			Person person = new Person(i);
			list.add(person);
		}
		return list;
	}
	
	
	public static void main(String[] args) throws Exception {
		ArrayList<Person> listOfStudents = createListOfPersons(1000);
		ArrayList<Person> listOfTutors = createListOfPersons(50);
		
		Scheduler sched = new Scheduler(listOfStudents, listOfTutors);
		sched.compute();
		
	}
}
