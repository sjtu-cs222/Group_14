package ats;

import java.util.Random;

public class Person {
	int[] pref;
	int assignedTimeSlot;
	int id;
	
	public Person(int givenId) {
		//create person with random preferences
		this.pref = new int[30];
		Random ran = new Random();
		for (int i = 0; i < pref.length; i++) {
			this.pref[i] = ran.nextInt(10) + 1;
		}
		this.assignedTimeSlot = -1;
		this.id = givenId;
	}
}
