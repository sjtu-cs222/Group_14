package ats;

import java.util.ArrayList;

public class Timeslot {

	ArrayList<Person> listOfStudents = new ArrayList<Person>();
	ArrayList<Person> listOfTutors = new ArrayList<Person>();

}
