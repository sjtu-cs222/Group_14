package ats;

import java.util.ArrayList;

public class Main {
	static int numberOfStudents = 1000; //parameter to set number of students
	static int numberOfTutors = 50;		//parameter to set number of tutors
	
	public static ArrayList<Person> createListOfPersons(int amount) {
		ArrayList<Person> list = new ArrayList<Person>();
		for (int i = 0; i < amount; i++) {
			Person person = new Person(i);
			list.add(person);
		}
		return list;
	}
	
	
	public static void main(String[] args) throws Exception {
		ArrayList<Person> listOfStudents = createListOfPersons(numberOfStudents);
		ArrayList<Person> listOfTutors = createListOfPersons(numberOfTutors);
		
		Scheduler sched = new Scheduler(listOfStudents, listOfTutors);
		sched.compute();
		
	}
}
