package ats;

import java.util.ArrayList;
import java.util.Arrays;

public class Scheduler {
	
	ArrayList<Person> listOfStudents;
	ArrayList<Person> listOfTutors;
	ArrayList<Timeslot> listOfTimeslots;
	double[] heatMap;
	int studentsTotal;
	int tutorsTotal;
	
	public Scheduler(ArrayList<Person> givenListOfStudents, ArrayList<Person> givenListOfTutors) throws Exception {
		if ( (double) givenListOfStudents.size() / 20 > givenListOfTutors.size()) {
			System.out.println("Not enough tutors for too many students!");
			throw new Exception();
		}
		this.listOfStudents = new ArrayList<Person>(givenListOfStudents);
		this.listOfTutors = new ArrayList<Person>(givenListOfTutors);
		this.listOfTimeslots = new ArrayList<Timeslot>();
		for (int i = 0; i < 30; i++) {
			listOfTimeslots.add(new Timeslot());
		}
		this.heatMap = new double[30];
		this.studentsTotal = listOfStudents.size();
		this.tutorsTotal = listOfTutors.size();
	}
	
	private void computeHeatMap() {
		Arrays.fill(heatMap, 0);
		for (int i = 0; i < listOfStudents.size(); i++) {
			for (int j = 0; j < listOfStudents.get(i).pref.length; j++) {
				heatMap[j] += listOfStudents.get(i).pref[j];
			}
		}
		for (int i = 0; i < listOfTutors.size(); i++) {
			for (int j = 0; j < listOfTutors.get(i).pref.length; j++) {
				heatMap[j] += listOfTutors.get(i).pref[j];
			}
		}		
		int tot = listOfStudents.size() + listOfTutors.size();
		for (int i = 0; i < heatMap.length; i++) {
			heatMap[i] /= tot;
		}
	}

	private int maxAt(double[] array) {
		int index = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] > array[index]) {
				index = i;
			}
		}
		return index;
	}
	
	private int maxAt(int[] array) {
		int index = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] > array[index]) {
				index = i;
			}
		}
		return index;
	}
	
	private void assignToTimeslot(int hottestSpot) {
		//assign max 20 students
		int freePlaces = 20;
		for (int i = 10; i > 0; i--) {
			for (int j = 0; j < listOfStudents.size(); j++) {
				if (freePlaces > 0 && listOfStudents.get(j).pref[hottestSpot] == i) {
					listOfTimeslots.get(hottestSpot).listOfStudents.add(listOfStudents.get(j));
					listOfStudents.remove(j);
					freePlaces--;
				}
			}
		}
		//assign one tutor
		freePlaces = 1;
		for (int i = 10; i > 0; i--) {
			for (int j = 0; j < listOfTutors.size(); j++) {
				if (freePlaces > 0 && listOfTutors.get(j).pref[hottestSpot] == i) {
					listOfTimeslots.get(hottestSpot).listOfTutors.add(listOfTutors.get(j));
					listOfTutors.remove(j);
					freePlaces--;
				}
			}
		}
	}
	
	public double utilityFunction() {
		int tot = 0;
		for (int i = 0; i < listOfTimeslots.size(); i++) {
			for (int j = 0; j < listOfTimeslots.get(i).listOfStudents.size(); j++) {
				tot += listOfTimeslots.get(i).listOfStudents.get(j).pref[i];
			}
			for (int j = 0; j < listOfTimeslots.get(i).listOfTutors.size(); j++) {
				tot += listOfTimeslots.get(i).listOfTutors.get(j).pref[i];
			}
		}
		return ((double) tot) / ((double) (studentsTotal + tutorsTotal));
	}
	
	private void improve() {
		for (int i = 0; i < listOfTimeslots.size(); i++) {
			for (int j = 0; j < listOfTimeslots.get(i).listOfStudents.size(); j++) {
				int maxPref = maxAt(listOfTimeslots.get(i).listOfStudents.get(j).pref);
				int currentPref = listOfTimeslots.get(i).listOfStudents.get(j).pref[i];
				if (maxPref > currentPref) {
					//if student did not get their highest preference, try to swap
					boolean swapDone = false;
					for (int k = 10; k > currentPref; k--) {
						for (int k2 = 0; k2 < listOfTimeslots.get(i).listOfStudents.get(j).pref.length; k2++) {
							if (!swapDone && listOfTimeslots.get(i).listOfStudents.get(j).pref[k2] == k) {
								for (int l = 0; l < listOfTimeslots.get(k2).listOfStudents.size(); l++) {
									if (!swapDone && listOfTimeslots.get(k2).listOfStudents.get(l).pref[i] > listOfTimeslots.get(k2).listOfStudents.get(l).pref[k2]) {
										//swap
										listOfTimeslots.get(k2).listOfStudents.add(listOfTimeslots.get(i).listOfStudents.get(j));
										listOfTimeslots.get(i).listOfStudents.add(listOfTimeslots.get(k2).listOfStudents.get(l));
										listOfTimeslots.get(k2).listOfStudents.remove(l);
										listOfTimeslots.get(i).listOfStudents.remove(j);
										swapDone = true;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	
	public void compute() {
		System.out.println("assigning tutorials according to heat map");
		int hottestSpot = 0;
		while (listOfStudents.size() > 0) {
			computeHeatMap();
			hottestSpot = maxAt(heatMap);
			assignToTimeslot(hottestSpot);
			System.out.println("heat map:");
			System.out.println(Arrays.toString(heatMap));
			System.out.println("hottest spot:");
			System.out.println(hottestSpot);
			System.out.println("\n");
		}
		System.out.println("done");
		System.out.println("utility function: " + utilityFunction());
		System.out.println("\n");
		
		//improve solution
		System.out.println("improving utility solution");
		improve();
		System.out.println("done");
		System.out.println("utility function: " + utilityFunction());
	}

}
