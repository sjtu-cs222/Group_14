Please set the number of students and tutors as attributes in the Main class and run.
This will create random persons with random preferences.